//
//  SignUpViewController.swift
//  Expensly_Capstone1.0
//
//  Created by Xcode User on 2017-10-03.
//  Copyright © 2017 Xcode User. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var firstName : UITextField!
    @IBOutlet var lastName : UITextField!
    @IBOutlet var email : UITextField!
    @IBOutlet var username : UITextField!
    @IBOutlet var password : UITextField!
    @IBOutlet var cPassword  : UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setTextFields()
        
        

        // Do any additional setup after loading the view.
    }
    
    //add email validator
    
    
    func setTextFields(){
        password.isSecureTextEntry = true
        cPassword.isSecureTextEntry = true
        firstName.setBottomBorder(borderColor: UIColor.white)
        lastName.setBottomBorder(borderColor: UIColor.white)
        email.setBottomBorder(borderColor: UIColor.white)
        username.setBottomBorder(borderColor: UIColor.white)
        password.setBottomBorder(borderColor: UIColor.white)
        cPassword.setBottomBorder(borderColor: UIColor.white)
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
 
}
extension UITextField {
    
    func setBottomBorder(borderColor: UIColor) {
        self.borderStyle = UITextBorderStyle.none
        self.backgroundColor = UIColor.clear
        self.textColor = UIColor.white
        let width = 1.5
        
        let borderLine = UIView()
        borderLine.frame = CGRect(x: 0, y: Double(self.frame.height) - width, width: Double(self.frame.width), height: width)
        
        borderLine.backgroundColor = borderColor
        self.addSubview(borderLine)
        //self.borderStyle = .none
        
        //self.layer.backgroundColor = UIColor.clear.cgColor
        
        
        
        //self.layer.masksToBounds = false
        
        //self.layer.shadowColor = UIColor.white.cgColor
        
        //self.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        
        //self.layer.shadowOpacity = 1.0
        
        //self.layer.shadowRadius = 0.0
        
    }
    
}
