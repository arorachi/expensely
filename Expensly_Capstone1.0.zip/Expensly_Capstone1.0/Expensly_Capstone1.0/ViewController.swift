//
//  ViewController.swift
//  Expensly_Capstone1.0
//
//  Created by Xcode User on 2017-09-23.
//  Copyright © 2017 Xcode User. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var username : UITextField!
    @IBOutlet var password : UITextField!
    @IBOutlet var signIn : UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpTextFields()
    }

    func setUpTextFields(){
        password.isSecureTextEntry = true
        username.setBottomBorder(borderColor: UIColor.white)
        password.setBottomBorder(borderColor: UIColor.white)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func unwindToThisViewController(segue: UIStoryboardSegue)
    {
        
    }

}

