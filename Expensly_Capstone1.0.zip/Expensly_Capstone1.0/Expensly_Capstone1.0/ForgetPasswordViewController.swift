//
//  ForgetPasswordViewController.swift
//  Expensly_Capstone1.0
//
//  Created by Xcode User on 2017-10-03.
//  Copyright © 2017 Xcode User. All rights reserved.
//

import UIKit

class ForgetPasswordViewController: UIViewController, UITextFieldDelegate {
    

    @IBOutlet var submitBtn : UIButton? //change this to a IBAction
    @IBOutlet var backBtn : UIButton?
    @IBOutlet var emailTextField : UITextField!
    
    //add email validator
    
    override func viewDidLoad() {
        super.viewDidLoad()
        emailTextField.setBottomBorder(borderColor: UIColor.white)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
