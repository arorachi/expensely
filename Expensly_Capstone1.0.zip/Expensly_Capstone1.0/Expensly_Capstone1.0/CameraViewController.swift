//
//  CameraViewController.swift
//  Expensly_Capstone1.0
//
//  Created by Xcode User on 2017-09-23.
//  Copyright © 2017 Xcode User. All rights reserved.
//

import UIKit

class CameraViewController: UIViewController {
    
    var receiptPhoto:UIImage?
    
    @IBOutlet weak var imageView:UIImageView!
    
    @IBAction func backButton(_sender: Any){
        
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func unwindToThisViewController(segue: UIStoryboardSegue)
    {
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        if let availableImage = receiptPhoto {
            imageView.image = availableImage
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
